/**
 */
package org.eclipse.uml.iod.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eclipse.uml.iod.Interaction;
import org.eclipse.uml.iod.IodPackage;
import org.eclipse.uml.iod.LoopParameters;
import org.eclipse.uml.iod.Operand;
import org.eclipse.uml.iod.oprdCondition;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Operand</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.eclipse.uml.iod.impl.OperandImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.eclipse.uml.iod.impl.OperandImpl#getOperandfragments <em>Operandfragments</em>}</li>
 *   <li>{@link org.eclipse.uml.iod.impl.OperandImpl#getLoopparameters <em>Loopparameters</em>}</li>
 *   <li>{@link org.eclipse.uml.iod.impl.OperandImpl#getGuard <em>Guard</em>}</li>
 * </ul>
 *
 * @generated
 */
public class OperandImpl extends MinimalEObjectImpl.Container implements Operand {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getOperandfragments() <em>Operandfragments</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOperandfragments()
	 * @generated
	 * @ordered
	 */
	protected EList<Interaction> operandfragments;

	/**
	 * The cached value of the '{@link #getLoopparameters() <em>Loopparameters</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLoopparameters()
	 * @generated
	 * @ordered
	 */
	protected EList<LoopParameters> loopparameters;

	/**
	 * The cached value of the '{@link #getGuard() <em>Guard</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGuard()
	 * @generated
	 * @ordered
	 */
	protected oprdCondition guard;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OperandImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return IodPackage.Literals.OPERAND;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IodPackage.OPERAND__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Interaction> getOperandfragments() {
		if (operandfragments == null) {
			operandfragments = new EObjectContainmentEList<Interaction>(Interaction.class, this,
					IodPackage.OPERAND__OPERANDFRAGMENTS);
		}
		return operandfragments;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<LoopParameters> getLoopparameters() {
		if (loopparameters == null) {
			loopparameters = new EObjectContainmentEList<LoopParameters>(LoopParameters.class, this,
					IodPackage.OPERAND__LOOPPARAMETERS);
		}
		return loopparameters;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public oprdCondition getGuard() {
		return guard;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetGuard(oprdCondition newGuard, NotificationChain msgs) {
		oprdCondition oldGuard = guard;
		guard = newGuard;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, IodPackage.OPERAND__GUARD,
					oldGuard, newGuard);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setGuard(oprdCondition newGuard) {
		if (newGuard != guard) {
			NotificationChain msgs = null;
			if (guard != null)
				msgs = ((InternalEObject) guard).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - IodPackage.OPERAND__GUARD, null, msgs);
			if (newGuard != null)
				msgs = ((InternalEObject) newGuard).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - IodPackage.OPERAND__GUARD, null, msgs);
			msgs = basicSetGuard(newGuard, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IodPackage.OPERAND__GUARD, newGuard, newGuard));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case IodPackage.OPERAND__OPERANDFRAGMENTS:
			return ((InternalEList<?>) getOperandfragments()).basicRemove(otherEnd, msgs);
		case IodPackage.OPERAND__LOOPPARAMETERS:
			return ((InternalEList<?>) getLoopparameters()).basicRemove(otherEnd, msgs);
		case IodPackage.OPERAND__GUARD:
			return basicSetGuard(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case IodPackage.OPERAND__NAME:
			return getName();
		case IodPackage.OPERAND__OPERANDFRAGMENTS:
			return getOperandfragments();
		case IodPackage.OPERAND__LOOPPARAMETERS:
			return getLoopparameters();
		case IodPackage.OPERAND__GUARD:
			return getGuard();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case IodPackage.OPERAND__NAME:
			setName((String) newValue);
			return;
		case IodPackage.OPERAND__OPERANDFRAGMENTS:
			getOperandfragments().clear();
			getOperandfragments().addAll((Collection<? extends Interaction>) newValue);
			return;
		case IodPackage.OPERAND__LOOPPARAMETERS:
			getLoopparameters().clear();
			getLoopparameters().addAll((Collection<? extends LoopParameters>) newValue);
			return;
		case IodPackage.OPERAND__GUARD:
			setGuard((oprdCondition) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case IodPackage.OPERAND__NAME:
			setName(NAME_EDEFAULT);
			return;
		case IodPackage.OPERAND__OPERANDFRAGMENTS:
			getOperandfragments().clear();
			return;
		case IodPackage.OPERAND__LOOPPARAMETERS:
			getLoopparameters().clear();
			return;
		case IodPackage.OPERAND__GUARD:
			setGuard((oprdCondition) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case IodPackage.OPERAND__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case IodPackage.OPERAND__OPERANDFRAGMENTS:
			return operandfragments != null && !operandfragments.isEmpty();
		case IodPackage.OPERAND__LOOPPARAMETERS:
			return loopparameters != null && !loopparameters.isEmpty();
		case IodPackage.OPERAND__GUARD:
			return guard != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //OperandImpl
