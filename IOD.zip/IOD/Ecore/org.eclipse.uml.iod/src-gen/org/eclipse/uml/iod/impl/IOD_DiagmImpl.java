/**
 */
package org.eclipse.uml.iod.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eclipse.uml.iod.IOD_Diagm;
import org.eclipse.uml.iod.IOD_Edge;
import org.eclipse.uml.iod.IOD_Node;
import org.eclipse.uml.iod.IodPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>IOD Diagm</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.eclipse.uml.iod.impl.IOD_DiagmImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.eclipse.uml.iod.impl.IOD_DiagmImpl#getNodes <em>Nodes</em>}</li>
 *   <li>{@link org.eclipse.uml.iod.impl.IOD_DiagmImpl#getEdges <em>Edges</em>}</li>
 * </ul>
 *
 * @generated
 */
public class IOD_DiagmImpl extends MinimalEObjectImpl.Container implements IOD_Diagm {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getNodes() <em>Nodes</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNodes()
	 * @generated
	 * @ordered
	 */
	protected EList<IOD_Node> nodes;

	/**
	 * The cached value of the '{@link #getEdges() <em>Edges</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEdges()
	 * @generated
	 * @ordered
	 */
	protected EList<IOD_Edge> edges;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IOD_DiagmImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return IodPackage.Literals.IOD_DIAGM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IodPackage.IOD_DIAGM__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<IOD_Node> getNodes() {
		if (nodes == null) {
			nodes = new EObjectContainmentEList<IOD_Node>(IOD_Node.class, this, IodPackage.IOD_DIAGM__NODES);
		}
		return nodes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<IOD_Edge> getEdges() {
		if (edges == null) {
			edges = new EObjectContainmentEList<IOD_Edge>(IOD_Edge.class, this, IodPackage.IOD_DIAGM__EDGES);
		}
		return edges;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case IodPackage.IOD_DIAGM__NODES:
			return ((InternalEList<?>) getNodes()).basicRemove(otherEnd, msgs);
		case IodPackage.IOD_DIAGM__EDGES:
			return ((InternalEList<?>) getEdges()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case IodPackage.IOD_DIAGM__NAME:
			return getName();
		case IodPackage.IOD_DIAGM__NODES:
			return getNodes();
		case IodPackage.IOD_DIAGM__EDGES:
			return getEdges();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case IodPackage.IOD_DIAGM__NAME:
			setName((String) newValue);
			return;
		case IodPackage.IOD_DIAGM__NODES:
			getNodes().clear();
			getNodes().addAll((Collection<? extends IOD_Node>) newValue);
			return;
		case IodPackage.IOD_DIAGM__EDGES:
			getEdges().clear();
			getEdges().addAll((Collection<? extends IOD_Edge>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case IodPackage.IOD_DIAGM__NAME:
			setName(NAME_EDEFAULT);
			return;
		case IodPackage.IOD_DIAGM__NODES:
			getNodes().clear();
			return;
		case IodPackage.IOD_DIAGM__EDGES:
			getEdges().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case IodPackage.IOD_DIAGM__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case IodPackage.IOD_DIAGM__NODES:
			return nodes != null && !nodes.isEmpty();
		case IodPackage.IOD_DIAGM__EDGES:
			return edges != null && !edges.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //IOD_DiagmImpl
