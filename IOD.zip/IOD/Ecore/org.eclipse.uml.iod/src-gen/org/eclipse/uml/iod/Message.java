/**
 */
package org.eclipse.uml.iod;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Message</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.eclipse.uml.iod.Message#getName <em>Name</em>}</li>
 *   <li>{@link org.eclipse.uml.iod.Message#getType <em>Type</em>}</li>
 *   <li>{@link org.eclipse.uml.iod.Message#getTarget <em>Target</em>}</li>
 *   <li>{@link org.eclipse.uml.iod.Message#getSource <em>Source</em>}</li>
 * </ul>
 *
 * @see org.eclipse.uml.iod.IodPackage#getMessage()
 * @model
 * @generated
 */
public interface Message extends Interaction {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.eclipse.uml.iod.IodPackage#getMessage_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.eclipse.uml.iod.Message#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link org.eclipse.uml.iod.MessageTypes}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see org.eclipse.uml.iod.MessageTypes
	 * @see #setType(MessageTypes)
	 * @see org.eclipse.uml.iod.IodPackage#getMessage_Type()
	 * @model
	 * @generated
	 */
	MessageTypes getType();

	/**
	 * Sets the value of the '{@link org.eclipse.uml.iod.Message#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see org.eclipse.uml.iod.MessageTypes
	 * @see #getType()
	 * @generated
	 */
	void setType(MessageTypes value);

	/**
	 * Returns the value of the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' reference.
	 * @see #setTarget(LifeLine)
	 * @see org.eclipse.uml.iod.IodPackage#getMessage_Target()
	 * @model required="true"
	 * @generated
	 */
	LifeLine getTarget();

	/**
	 * Sets the value of the '{@link org.eclipse.uml.iod.Message#getTarget <em>Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target</em>' reference.
	 * @see #getTarget()
	 * @generated
	 */
	void setTarget(LifeLine value);

	/**
	 * Returns the value of the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' reference.
	 * @see #setSource(LifeLine)
	 * @see org.eclipse.uml.iod.IodPackage#getMessage_Source()
	 * @model required="true"
	 * @generated
	 */
	LifeLine getSource();

	/**
	 * Sets the value of the '{@link org.eclipse.uml.iod.Message#getSource <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' reference.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(LifeLine value);

} // Message
