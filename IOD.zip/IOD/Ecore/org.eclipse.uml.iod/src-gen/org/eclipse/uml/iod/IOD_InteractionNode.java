/**
 */
package org.eclipse.uml.iod;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>IOD Interaction Node</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.eclipse.uml.iod.IOD_InteractionNode#getFragments <em>Fragments</em>}</li>
 *   <li>{@link org.eclipse.uml.iod.IOD_InteractionNode#getLifeline <em>Lifeline</em>}</li>
 * </ul>
 *
 * @see org.eclipse.uml.iod.IodPackage#getIOD_InteractionNode()
 * @model
 * @generated
 */
public interface IOD_InteractionNode extends IOD_Node {
	/**
	 * Returns the value of the '<em><b>Fragments</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.uml.iod.Interaction}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fragments</em>' containment reference list.
	 * @see org.eclipse.uml.iod.IodPackage#getIOD_InteractionNode_Fragments()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Interaction> getFragments();

	/**
	 * Returns the value of the '<em><b>Lifeline</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.uml.iod.LifeLine}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lifeline</em>' containment reference list.
	 * @see org.eclipse.uml.iod.IodPackage#getIOD_InteractionNode_Lifeline()
	 * @model containment="true" lower="2"
	 * @generated
	 */
	EList<LifeLine> getLifeline();

} // IOD_InteractionNode
