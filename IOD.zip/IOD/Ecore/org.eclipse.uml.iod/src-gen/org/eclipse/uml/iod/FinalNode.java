/**
 */
package org.eclipse.uml.iod;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Final Node</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.uml.iod.IodPackage#getFinalNode()
 * @model
 * @generated
 */
public interface FinalNode extends IOD_ControlNode {
} // FinalNode
