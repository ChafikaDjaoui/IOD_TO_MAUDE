/**
 */
package org.eclipse.uml.iod;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Interaction</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.uml.iod.IodPackage#getInteraction()
 * @model
 * @generated
 */
public interface Interaction extends EObject {
} // Interaction
