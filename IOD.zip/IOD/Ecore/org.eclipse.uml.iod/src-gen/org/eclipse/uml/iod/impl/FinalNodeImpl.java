/**
 */
package org.eclipse.uml.iod.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.uml.iod.FinalNode;
import org.eclipse.uml.iod.IodPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Final Node</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class FinalNodeImpl extends IOD_ControlNodeImpl implements FinalNode {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FinalNodeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return IodPackage.Literals.FINAL_NODE;
	}

} //FinalNodeImpl
