/**
 */
package org.eclipse.uml.iod;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>IOD Control Node</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.uml.iod.IodPackage#getIOD_ControlNode()
 * @model
 * @generated
 */
public interface IOD_ControlNode extends IOD_Node {
} // IOD_ControlNode
