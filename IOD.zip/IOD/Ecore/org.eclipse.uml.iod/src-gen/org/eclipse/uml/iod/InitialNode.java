/**
 */
package org.eclipse.uml.iod;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial Node</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.uml.iod.IodPackage#getInitialNode()
 * @model
 * @generated
 */
public interface InitialNode extends IOD_ControlNode {
} // InitialNode
