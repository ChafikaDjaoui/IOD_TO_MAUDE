/**
 */
package org.eclipse.uml.iod.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import org.eclipse.uml.iod.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class IodFactoryImpl extends EFactoryImpl implements IodFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static IodFactory init() {
		try {
			IodFactory theIodFactory = (IodFactory) EPackage.Registry.INSTANCE.getEFactory(IodPackage.eNS_URI);
			if (theIodFactory != null) {
				return theIodFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new IodFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IodFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case IodPackage.IOD_DIAGM:
			return createIOD_Diagm();
		case IodPackage.IOD_EDGE:
			return createIOD_Edge();
		case IodPackage.IOD_NODE:
			return createIOD_Node();
		case IodPackage.IOD_INTERACTION_NODE:
			return createIOD_InteractionNode();
		case IodPackage.EDGE_CONDITION:
			return createEdgeCondition();
		case IodPackage.INTERACTION:
			return createInteraction();
		case IodPackage.IOD_CONTROL_NODE:
			return createIOD_ControlNode();
		case IodPackage.INITIAL_NODE:
			return createInitialNode();
		case IodPackage.FINAL_NODE:
			return createFinalNode();
		case IodPackage.FORK_NODE:
			return createForkNode();
		case IodPackage.DECISION_NODE:
			return createDecisionNode();
		case IodPackage.JOIN_NODE:
			return createJoinNode();
		case IodPackage.MERGE_NODE:
			return createMergeNode();
		case IodPackage.LIFE_LINE:
			return createLifeLine();
		case IodPackage.COMBINED_FRAGMENT:
			return createCombinedFragment();
		case IodPackage.MESSAGE:
			return createMessage();
		case IodPackage.OPERAND:
			return createOperand();
		case IodPackage.OPRD_CONDITION:
			return createoprdCondition();
		case IodPackage.LOOP_PARAMETERS:
			return createLoopParameters();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
		case IodPackage.OPERATOR_TYPES:
			return createOperatorTypesFromString(eDataType, initialValue);
		case IodPackage.LL_TYPES:
			return createLLTypesFromString(eDataType, initialValue);
		case IodPackage.MESSAGE_TYPES:
			return createMessageTypesFromString(eDataType, initialValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case IodPackage.OPERATOR_TYPES:
			return convertOperatorTypesToString(eDataType, instanceValue);
		case IodPackage.LL_TYPES:
			return convertLLTypesToString(eDataType, instanceValue);
		case IodPackage.MESSAGE_TYPES:
			return convertMessageTypesToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IOD_Diagm createIOD_Diagm() {
		IOD_DiagmImpl ioD_Diagm = new IOD_DiagmImpl();
		return ioD_Diagm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IOD_Edge createIOD_Edge() {
		IOD_EdgeImpl ioD_Edge = new IOD_EdgeImpl();
		return ioD_Edge;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IOD_Node createIOD_Node() {
		IOD_NodeImpl ioD_Node = new IOD_NodeImpl();
		return ioD_Node;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IOD_InteractionNode createIOD_InteractionNode() {
		IOD_InteractionNodeImpl ioD_InteractionNode = new IOD_InteractionNodeImpl();
		return ioD_InteractionNode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EdgeCondition createEdgeCondition() {
		EdgeConditionImpl edgeCondition = new EdgeConditionImpl();
		return edgeCondition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Interaction createInteraction() {
		InteractionImpl interaction = new InteractionImpl();
		return interaction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IOD_ControlNode createIOD_ControlNode() {
		IOD_ControlNodeImpl ioD_ControlNode = new IOD_ControlNodeImpl();
		return ioD_ControlNode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InitialNode createInitialNode() {
		InitialNodeImpl initialNode = new InitialNodeImpl();
		return initialNode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FinalNode createFinalNode() {
		FinalNodeImpl finalNode = new FinalNodeImpl();
		return finalNode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ForkNode createForkNode() {
		ForkNodeImpl forkNode = new ForkNodeImpl();
		return forkNode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DecisionNode createDecisionNode() {
		DecisionNodeImpl decisionNode = new DecisionNodeImpl();
		return decisionNode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public JoinNode createJoinNode() {
		JoinNodeImpl joinNode = new JoinNodeImpl();
		return joinNode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MergeNode createMergeNode() {
		MergeNodeImpl mergeNode = new MergeNodeImpl();
		return mergeNode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LifeLine createLifeLine() {
		LifeLineImpl lifeLine = new LifeLineImpl();
		return lifeLine;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CombinedFragment createCombinedFragment() {
		CombinedFragmentImpl combinedFragment = new CombinedFragmentImpl();
		return combinedFragment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Message createMessage() {
		MessageImpl message = new MessageImpl();
		return message;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Operand createOperand() {
		OperandImpl operand = new OperandImpl();
		return operand;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public oprdCondition createoprdCondition() {
		oprdConditionImpl oprdCondition = new oprdConditionImpl();
		return oprdCondition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LoopParameters createLoopParameters() {
		LoopParametersImpl loopParameters = new LoopParametersImpl();
		return loopParameters;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OperatorTypes createOperatorTypesFromString(EDataType eDataType, String initialValue) {
		OperatorTypes result = OperatorTypes.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertOperatorTypesToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LLTypes createLLTypesFromString(EDataType eDataType, String initialValue) {
		LLTypes result = LLTypes.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertLLTypesToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MessageTypes createMessageTypesFromString(EDataType eDataType, String initialValue) {
		MessageTypes result = MessageTypes.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertMessageTypesToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IodPackage getIodPackage() {
		return (IodPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static IodPackage getPackage() {
		return IodPackage.eINSTANCE;
	}

} //IodFactoryImpl
