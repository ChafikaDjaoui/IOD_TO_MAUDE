/**
 */
package org.eclipse.uml.iod.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.uml.iod.IOD_ControlNode;
import org.eclipse.uml.iod.IodPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>IOD Control Node</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class IOD_ControlNodeImpl extends IOD_NodeImpl implements IOD_ControlNode {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IOD_ControlNodeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return IodPackage.Literals.IOD_CONTROL_NODE;
	}

} //IOD_ControlNodeImpl
