/**
 */
package org.eclipse.uml.iod;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fork Node</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.uml.iod.IodPackage#getForkNode()
 * @model
 * @generated
 */
public interface ForkNode extends IOD_ControlNode {
} // ForkNode
