/**
 */
package org.eclipse.uml.iod;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.eclipse.uml.iod.IodFactory
 * @model kind="package"
 * @generated
 */
public interface IodPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "iod";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/iod";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "iod";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	IodPackage eINSTANCE = org.eclipse.uml.iod.impl.IodPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.eclipse.uml.iod.impl.IOD_DiagmImpl <em>IOD Diagm</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.uml.iod.impl.IOD_DiagmImpl
	 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getIOD_Diagm()
	 * @generated
	 */
	int IOD_DIAGM = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IOD_DIAGM__NAME = 0;

	/**
	 * The feature id for the '<em><b>Nodes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IOD_DIAGM__NODES = 1;

	/**
	 * The feature id for the '<em><b>Edges</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IOD_DIAGM__EDGES = 2;

	/**
	 * The number of structural features of the '<em>IOD Diagm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IOD_DIAGM_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>IOD Diagm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IOD_DIAGM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.eclipse.uml.iod.impl.IOD_EdgeImpl <em>IOD Edge</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.uml.iod.impl.IOD_EdgeImpl
	 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getIOD_Edge()
	 * @generated
	 */
	int IOD_EDGE = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IOD_EDGE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IOD_EDGE__SOURCE = 1;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IOD_EDGE__TARGET = 2;

	/**
	 * The feature id for the '<em><b>Guard</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IOD_EDGE__GUARD = 3;

	/**
	 * The number of structural features of the '<em>IOD Edge</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IOD_EDGE_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>IOD Edge</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IOD_EDGE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.eclipse.uml.iod.impl.IOD_NodeImpl <em>IOD Node</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.uml.iod.impl.IOD_NodeImpl
	 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getIOD_Node()
	 * @generated
	 */
	int IOD_NODE = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IOD_NODE__NAME = 0;

	/**
	 * The number of structural features of the '<em>IOD Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IOD_NODE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>IOD Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IOD_NODE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.eclipse.uml.iod.impl.IOD_InteractionNodeImpl <em>IOD Interaction Node</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.uml.iod.impl.IOD_InteractionNodeImpl
	 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getIOD_InteractionNode()
	 * @generated
	 */
	int IOD_INTERACTION_NODE = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IOD_INTERACTION_NODE__NAME = IOD_NODE__NAME;

	/**
	 * The feature id for the '<em><b>Fragments</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IOD_INTERACTION_NODE__FRAGMENTS = IOD_NODE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Lifeline</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IOD_INTERACTION_NODE__LIFELINE = IOD_NODE_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>IOD Interaction Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IOD_INTERACTION_NODE_FEATURE_COUNT = IOD_NODE_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>IOD Interaction Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IOD_INTERACTION_NODE_OPERATION_COUNT = IOD_NODE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.uml.iod.impl.EdgeConditionImpl <em>Edge Condition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.uml.iod.impl.EdgeConditionImpl
	 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getEdgeCondition()
	 * @generated
	 */
	int EDGE_CONDITION = 4;

	/**
	 * The feature id for the '<em><b>Clause</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EDGE_CONDITION__CLAUSE = 0;

	/**
	 * The number of structural features of the '<em>Edge Condition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EDGE_CONDITION_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Edge Condition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EDGE_CONDITION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.eclipse.uml.iod.impl.InteractionImpl <em>Interaction</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.uml.iod.impl.InteractionImpl
	 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getInteraction()
	 * @generated
	 */
	int INTERACTION = 5;

	/**
	 * The number of structural features of the '<em>Interaction</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTION_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Interaction</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.eclipse.uml.iod.impl.IOD_ControlNodeImpl <em>IOD Control Node</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.uml.iod.impl.IOD_ControlNodeImpl
	 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getIOD_ControlNode()
	 * @generated
	 */
	int IOD_CONTROL_NODE = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IOD_CONTROL_NODE__NAME = IOD_NODE__NAME;

	/**
	 * The number of structural features of the '<em>IOD Control Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IOD_CONTROL_NODE_FEATURE_COUNT = IOD_NODE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>IOD Control Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IOD_CONTROL_NODE_OPERATION_COUNT = IOD_NODE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.uml.iod.impl.InitialNodeImpl <em>Initial Node</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.uml.iod.impl.InitialNodeImpl
	 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getInitialNode()
	 * @generated
	 */
	int INITIAL_NODE = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INITIAL_NODE__NAME = IOD_CONTROL_NODE__NAME;

	/**
	 * The number of structural features of the '<em>Initial Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INITIAL_NODE_FEATURE_COUNT = IOD_CONTROL_NODE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Initial Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INITIAL_NODE_OPERATION_COUNT = IOD_CONTROL_NODE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.uml.iod.impl.FinalNodeImpl <em>Final Node</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.uml.iod.impl.FinalNodeImpl
	 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getFinalNode()
	 * @generated
	 */
	int FINAL_NODE = 8;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FINAL_NODE__NAME = IOD_CONTROL_NODE__NAME;

	/**
	 * The number of structural features of the '<em>Final Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FINAL_NODE_FEATURE_COUNT = IOD_CONTROL_NODE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Final Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FINAL_NODE_OPERATION_COUNT = IOD_CONTROL_NODE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.uml.iod.impl.ForkNodeImpl <em>Fork Node</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.uml.iod.impl.ForkNodeImpl
	 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getForkNode()
	 * @generated
	 */
	int FORK_NODE = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FORK_NODE__NAME = IOD_CONTROL_NODE__NAME;

	/**
	 * The number of structural features of the '<em>Fork Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FORK_NODE_FEATURE_COUNT = IOD_CONTROL_NODE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Fork Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FORK_NODE_OPERATION_COUNT = IOD_CONTROL_NODE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.uml.iod.impl.DecisionNodeImpl <em>Decision Node</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.uml.iod.impl.DecisionNodeImpl
	 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getDecisionNode()
	 * @generated
	 */
	int DECISION_NODE = 10;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION_NODE__NAME = IOD_CONTROL_NODE__NAME;

	/**
	 * The number of structural features of the '<em>Decision Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION_NODE_FEATURE_COUNT = IOD_CONTROL_NODE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Decision Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION_NODE_OPERATION_COUNT = IOD_CONTROL_NODE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.uml.iod.impl.JoinNodeImpl <em>Join Node</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.uml.iod.impl.JoinNodeImpl
	 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getJoinNode()
	 * @generated
	 */
	int JOIN_NODE = 11;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JOIN_NODE__NAME = IOD_CONTROL_NODE__NAME;

	/**
	 * The number of structural features of the '<em>Join Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JOIN_NODE_FEATURE_COUNT = IOD_CONTROL_NODE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Join Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JOIN_NODE_OPERATION_COUNT = IOD_CONTROL_NODE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.uml.iod.impl.MergeNodeImpl <em>Merge Node</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.uml.iod.impl.MergeNodeImpl
	 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getMergeNode()
	 * @generated
	 */
	int MERGE_NODE = 12;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MERGE_NODE__NAME = IOD_CONTROL_NODE__NAME;

	/**
	 * The number of structural features of the '<em>Merge Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MERGE_NODE_FEATURE_COUNT = IOD_CONTROL_NODE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Merge Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MERGE_NODE_OPERATION_COUNT = IOD_CONTROL_NODE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.uml.iod.impl.LifeLineImpl <em>Life Line</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.uml.iod.impl.LifeLineImpl
	 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getLifeLine()
	 * @generated
	 */
	int LIFE_LINE = 13;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIFE_LINE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIFE_LINE__TYPE = 1;

	/**
	 * The number of structural features of the '<em>Life Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIFE_LINE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Life Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIFE_LINE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.eclipse.uml.iod.impl.CombinedFragmentImpl <em>Combined Fragment</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.uml.iod.impl.CombinedFragmentImpl
	 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getCombinedFragment()
	 * @generated
	 */
	int COMBINED_FRAGMENT = 14;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMBINED_FRAGMENT__NAME = INTERACTION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMBINED_FRAGMENT__TYPE = INTERACTION_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Operands</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMBINED_FRAGMENT__OPERANDS = INTERACTION_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Combined Fragment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMBINED_FRAGMENT_FEATURE_COUNT = INTERACTION_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Combined Fragment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMBINED_FRAGMENT_OPERATION_COUNT = INTERACTION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.uml.iod.impl.MessageImpl <em>Message</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.uml.iod.impl.MessageImpl
	 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getMessage()
	 * @generated
	 */
	int MESSAGE = 15;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MESSAGE__NAME = INTERACTION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MESSAGE__TYPE = INTERACTION_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MESSAGE__TARGET = INTERACTION_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MESSAGE__SOURCE = INTERACTION_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Message</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MESSAGE_FEATURE_COUNT = INTERACTION_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Message</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MESSAGE_OPERATION_COUNT = INTERACTION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.uml.iod.impl.OperandImpl <em>Operand</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.uml.iod.impl.OperandImpl
	 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getOperand()
	 * @generated
	 */
	int OPERAND = 16;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERAND__NAME = 0;

	/**
	 * The feature id for the '<em><b>Operandfragments</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERAND__OPERANDFRAGMENTS = 1;

	/**
	 * The feature id for the '<em><b>Loopparameters</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERAND__LOOPPARAMETERS = 2;

	/**
	 * The feature id for the '<em><b>Guard</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERAND__GUARD = 3;

	/**
	 * The number of structural features of the '<em>Operand</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERAND_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Operand</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERAND_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.eclipse.uml.iod.impl.oprdConditionImpl <em>oprd Condition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.uml.iod.impl.oprdConditionImpl
	 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getoprdCondition()
	 * @generated
	 */
	int OPRD_CONDITION = 17;

	/**
	 * The feature id for the '<em><b>Clause</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPRD_CONDITION__CLAUSE = 0;

	/**
	 * The number of structural features of the '<em>oprd Condition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPRD_CONDITION_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>oprd Condition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPRD_CONDITION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.eclipse.uml.iod.impl.LoopParametersImpl <em>Loop Parameters</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.uml.iod.impl.LoopParametersImpl
	 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getLoopParameters()
	 * @generated
	 */
	int LOOP_PARAMETERS = 18;

	/**
	 * The feature id for the '<em><b>Loop Min</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOOP_PARAMETERS__LOOP_MIN = 0;

	/**
	 * The feature id for the '<em><b>Loop Max</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOOP_PARAMETERS__LOOP_MAX = 1;

	/**
	 * The number of structural features of the '<em>Loop Parameters</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOOP_PARAMETERS_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Loop Parameters</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOOP_PARAMETERS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.eclipse.uml.iod.OperatorTypes <em>Operator Types</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.uml.iod.OperatorTypes
	 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getOperatorTypes()
	 * @generated
	 */
	int OPERATOR_TYPES = 19;

	/**
	 * The meta object id for the '{@link org.eclipse.uml.iod.LLTypes <em>LL Types</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.uml.iod.LLTypes
	 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getLLTypes()
	 * @generated
	 */
	int LL_TYPES = 20;

	/**
	 * The meta object id for the '{@link org.eclipse.uml.iod.MessageTypes <em>Message Types</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.uml.iod.MessageTypes
	 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getMessageTypes()
	 * @generated
	 */
	int MESSAGE_TYPES = 21;

	/**
	 * Returns the meta object for class '{@link org.eclipse.uml.iod.IOD_Diagm <em>IOD Diagm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>IOD Diagm</em>'.
	 * @see org.eclipse.uml.iod.IOD_Diagm
	 * @generated
	 */
	EClass getIOD_Diagm();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.uml.iod.IOD_Diagm#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eclipse.uml.iod.IOD_Diagm#getName()
	 * @see #getIOD_Diagm()
	 * @generated
	 */
	EAttribute getIOD_Diagm_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eclipse.uml.iod.IOD_Diagm#getNodes <em>Nodes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Nodes</em>'.
	 * @see org.eclipse.uml.iod.IOD_Diagm#getNodes()
	 * @see #getIOD_Diagm()
	 * @generated
	 */
	EReference getIOD_Diagm_Nodes();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eclipse.uml.iod.IOD_Diagm#getEdges <em>Edges</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Edges</em>'.
	 * @see org.eclipse.uml.iod.IOD_Diagm#getEdges()
	 * @see #getIOD_Diagm()
	 * @generated
	 */
	EReference getIOD_Diagm_Edges();

	/**
	 * Returns the meta object for class '{@link org.eclipse.uml.iod.IOD_Edge <em>IOD Edge</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>IOD Edge</em>'.
	 * @see org.eclipse.uml.iod.IOD_Edge
	 * @generated
	 */
	EClass getIOD_Edge();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.uml.iod.IOD_Edge#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eclipse.uml.iod.IOD_Edge#getName()
	 * @see #getIOD_Edge()
	 * @generated
	 */
	EAttribute getIOD_Edge_Name();

	/**
	 * Returns the meta object for the reference '{@link org.eclipse.uml.iod.IOD_Edge#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see org.eclipse.uml.iod.IOD_Edge#getSource()
	 * @see #getIOD_Edge()
	 * @generated
	 */
	EReference getIOD_Edge_Source();

	/**
	 * Returns the meta object for the reference '{@link org.eclipse.uml.iod.IOD_Edge#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see org.eclipse.uml.iod.IOD_Edge#getTarget()
	 * @see #getIOD_Edge()
	 * @generated
	 */
	EReference getIOD_Edge_Target();

	/**
	 * Returns the meta object for the containment reference '{@link org.eclipse.uml.iod.IOD_Edge#getGuard <em>Guard</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Guard</em>'.
	 * @see org.eclipse.uml.iod.IOD_Edge#getGuard()
	 * @see #getIOD_Edge()
	 * @generated
	 */
	EReference getIOD_Edge_Guard();

	/**
	 * Returns the meta object for class '{@link org.eclipse.uml.iod.IOD_Node <em>IOD Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>IOD Node</em>'.
	 * @see org.eclipse.uml.iod.IOD_Node
	 * @generated
	 */
	EClass getIOD_Node();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.uml.iod.IOD_Node#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eclipse.uml.iod.IOD_Node#getName()
	 * @see #getIOD_Node()
	 * @generated
	 */
	EAttribute getIOD_Node_Name();

	/**
	 * Returns the meta object for class '{@link org.eclipse.uml.iod.IOD_InteractionNode <em>IOD Interaction Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>IOD Interaction Node</em>'.
	 * @see org.eclipse.uml.iod.IOD_InteractionNode
	 * @generated
	 */
	EClass getIOD_InteractionNode();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eclipse.uml.iod.IOD_InteractionNode#getFragments <em>Fragments</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Fragments</em>'.
	 * @see org.eclipse.uml.iod.IOD_InteractionNode#getFragments()
	 * @see #getIOD_InteractionNode()
	 * @generated
	 */
	EReference getIOD_InteractionNode_Fragments();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eclipse.uml.iod.IOD_InteractionNode#getLifeline <em>Lifeline</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Lifeline</em>'.
	 * @see org.eclipse.uml.iod.IOD_InteractionNode#getLifeline()
	 * @see #getIOD_InteractionNode()
	 * @generated
	 */
	EReference getIOD_InteractionNode_Lifeline();

	/**
	 * Returns the meta object for class '{@link org.eclipse.uml.iod.EdgeCondition <em>Edge Condition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Edge Condition</em>'.
	 * @see org.eclipse.uml.iod.EdgeCondition
	 * @generated
	 */
	EClass getEdgeCondition();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.uml.iod.EdgeCondition#getClause <em>Clause</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Clause</em>'.
	 * @see org.eclipse.uml.iod.EdgeCondition#getClause()
	 * @see #getEdgeCondition()
	 * @generated
	 */
	EAttribute getEdgeCondition_Clause();

	/**
	 * Returns the meta object for class '{@link org.eclipse.uml.iod.Interaction <em>Interaction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Interaction</em>'.
	 * @see org.eclipse.uml.iod.Interaction
	 * @generated
	 */
	EClass getInteraction();

	/**
	 * Returns the meta object for class '{@link org.eclipse.uml.iod.IOD_ControlNode <em>IOD Control Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>IOD Control Node</em>'.
	 * @see org.eclipse.uml.iod.IOD_ControlNode
	 * @generated
	 */
	EClass getIOD_ControlNode();

	/**
	 * Returns the meta object for class '{@link org.eclipse.uml.iod.InitialNode <em>Initial Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Initial Node</em>'.
	 * @see org.eclipse.uml.iod.InitialNode
	 * @generated
	 */
	EClass getInitialNode();

	/**
	 * Returns the meta object for class '{@link org.eclipse.uml.iod.FinalNode <em>Final Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Final Node</em>'.
	 * @see org.eclipse.uml.iod.FinalNode
	 * @generated
	 */
	EClass getFinalNode();

	/**
	 * Returns the meta object for class '{@link org.eclipse.uml.iod.ForkNode <em>Fork Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Fork Node</em>'.
	 * @see org.eclipse.uml.iod.ForkNode
	 * @generated
	 */
	EClass getForkNode();

	/**
	 * Returns the meta object for class '{@link org.eclipse.uml.iod.DecisionNode <em>Decision Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Decision Node</em>'.
	 * @see org.eclipse.uml.iod.DecisionNode
	 * @generated
	 */
	EClass getDecisionNode();

	/**
	 * Returns the meta object for class '{@link org.eclipse.uml.iod.JoinNode <em>Join Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Join Node</em>'.
	 * @see org.eclipse.uml.iod.JoinNode
	 * @generated
	 */
	EClass getJoinNode();

	/**
	 * Returns the meta object for class '{@link org.eclipse.uml.iod.MergeNode <em>Merge Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Merge Node</em>'.
	 * @see org.eclipse.uml.iod.MergeNode
	 * @generated
	 */
	EClass getMergeNode();

	/**
	 * Returns the meta object for class '{@link org.eclipse.uml.iod.LifeLine <em>Life Line</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Life Line</em>'.
	 * @see org.eclipse.uml.iod.LifeLine
	 * @generated
	 */
	EClass getLifeLine();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.uml.iod.LifeLine#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eclipse.uml.iod.LifeLine#getName()
	 * @see #getLifeLine()
	 * @generated
	 */
	EAttribute getLifeLine_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.uml.iod.LifeLine#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see org.eclipse.uml.iod.LifeLine#getType()
	 * @see #getLifeLine()
	 * @generated
	 */
	EAttribute getLifeLine_Type();

	/**
	 * Returns the meta object for class '{@link org.eclipse.uml.iod.CombinedFragment <em>Combined Fragment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Combined Fragment</em>'.
	 * @see org.eclipse.uml.iod.CombinedFragment
	 * @generated
	 */
	EClass getCombinedFragment();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.uml.iod.CombinedFragment#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eclipse.uml.iod.CombinedFragment#getName()
	 * @see #getCombinedFragment()
	 * @generated
	 */
	EAttribute getCombinedFragment_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.uml.iod.CombinedFragment#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see org.eclipse.uml.iod.CombinedFragment#getType()
	 * @see #getCombinedFragment()
	 * @generated
	 */
	EAttribute getCombinedFragment_Type();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eclipse.uml.iod.CombinedFragment#getOperands <em>Operands</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Operands</em>'.
	 * @see org.eclipse.uml.iod.CombinedFragment#getOperands()
	 * @see #getCombinedFragment()
	 * @generated
	 */
	EReference getCombinedFragment_Operands();

	/**
	 * Returns the meta object for class '{@link org.eclipse.uml.iod.Message <em>Message</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Message</em>'.
	 * @see org.eclipse.uml.iod.Message
	 * @generated
	 */
	EClass getMessage();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.uml.iod.Message#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eclipse.uml.iod.Message#getName()
	 * @see #getMessage()
	 * @generated
	 */
	EAttribute getMessage_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.uml.iod.Message#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see org.eclipse.uml.iod.Message#getType()
	 * @see #getMessage()
	 * @generated
	 */
	EAttribute getMessage_Type();

	/**
	 * Returns the meta object for the reference '{@link org.eclipse.uml.iod.Message#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see org.eclipse.uml.iod.Message#getTarget()
	 * @see #getMessage()
	 * @generated
	 */
	EReference getMessage_Target();

	/**
	 * Returns the meta object for the reference '{@link org.eclipse.uml.iod.Message#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see org.eclipse.uml.iod.Message#getSource()
	 * @see #getMessage()
	 * @generated
	 */
	EReference getMessage_Source();

	/**
	 * Returns the meta object for class '{@link org.eclipse.uml.iod.Operand <em>Operand</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Operand</em>'.
	 * @see org.eclipse.uml.iod.Operand
	 * @generated
	 */
	EClass getOperand();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.uml.iod.Operand#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eclipse.uml.iod.Operand#getName()
	 * @see #getOperand()
	 * @generated
	 */
	EAttribute getOperand_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eclipse.uml.iod.Operand#getOperandfragments <em>Operandfragments</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Operandfragments</em>'.
	 * @see org.eclipse.uml.iod.Operand#getOperandfragments()
	 * @see #getOperand()
	 * @generated
	 */
	EReference getOperand_Operandfragments();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eclipse.uml.iod.Operand#getLoopparameters <em>Loopparameters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Loopparameters</em>'.
	 * @see org.eclipse.uml.iod.Operand#getLoopparameters()
	 * @see #getOperand()
	 * @generated
	 */
	EReference getOperand_Loopparameters();

	/**
	 * Returns the meta object for the containment reference '{@link org.eclipse.uml.iod.Operand#getGuard <em>Guard</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Guard</em>'.
	 * @see org.eclipse.uml.iod.Operand#getGuard()
	 * @see #getOperand()
	 * @generated
	 */
	EReference getOperand_Guard();

	/**
	 * Returns the meta object for class '{@link org.eclipse.uml.iod.oprdCondition <em>oprd Condition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>oprd Condition</em>'.
	 * @see org.eclipse.uml.iod.oprdCondition
	 * @generated
	 */
	EClass getoprdCondition();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.uml.iod.oprdCondition#getClause <em>Clause</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Clause</em>'.
	 * @see org.eclipse.uml.iod.oprdCondition#getClause()
	 * @see #getoprdCondition()
	 * @generated
	 */
	EAttribute getoprdCondition_Clause();

	/**
	 * Returns the meta object for class '{@link org.eclipse.uml.iod.LoopParameters <em>Loop Parameters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Loop Parameters</em>'.
	 * @see org.eclipse.uml.iod.LoopParameters
	 * @generated
	 */
	EClass getLoopParameters();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.uml.iod.LoopParameters#getLoopMin <em>Loop Min</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Loop Min</em>'.
	 * @see org.eclipse.uml.iod.LoopParameters#getLoopMin()
	 * @see #getLoopParameters()
	 * @generated
	 */
	EAttribute getLoopParameters_LoopMin();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.uml.iod.LoopParameters#getLoopMax <em>Loop Max</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Loop Max</em>'.
	 * @see org.eclipse.uml.iod.LoopParameters#getLoopMax()
	 * @see #getLoopParameters()
	 * @generated
	 */
	EAttribute getLoopParameters_LoopMax();

	/**
	 * Returns the meta object for enum '{@link org.eclipse.uml.iod.OperatorTypes <em>Operator Types</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Operator Types</em>'.
	 * @see org.eclipse.uml.iod.OperatorTypes
	 * @generated
	 */
	EEnum getOperatorTypes();

	/**
	 * Returns the meta object for enum '{@link org.eclipse.uml.iod.LLTypes <em>LL Types</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>LL Types</em>'.
	 * @see org.eclipse.uml.iod.LLTypes
	 * @generated
	 */
	EEnum getLLTypes();

	/**
	 * Returns the meta object for enum '{@link org.eclipse.uml.iod.MessageTypes <em>Message Types</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Message Types</em>'.
	 * @see org.eclipse.uml.iod.MessageTypes
	 * @generated
	 */
	EEnum getMessageTypes();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	IodFactory getIodFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.eclipse.uml.iod.impl.IOD_DiagmImpl <em>IOD Diagm</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.uml.iod.impl.IOD_DiagmImpl
		 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getIOD_Diagm()
		 * @generated
		 */
		EClass IOD_DIAGM = eINSTANCE.getIOD_Diagm();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute IOD_DIAGM__NAME = eINSTANCE.getIOD_Diagm_Name();

		/**
		 * The meta object literal for the '<em><b>Nodes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IOD_DIAGM__NODES = eINSTANCE.getIOD_Diagm_Nodes();

		/**
		 * The meta object literal for the '<em><b>Edges</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IOD_DIAGM__EDGES = eINSTANCE.getIOD_Diagm_Edges();

		/**
		 * The meta object literal for the '{@link org.eclipse.uml.iod.impl.IOD_EdgeImpl <em>IOD Edge</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.uml.iod.impl.IOD_EdgeImpl
		 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getIOD_Edge()
		 * @generated
		 */
		EClass IOD_EDGE = eINSTANCE.getIOD_Edge();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute IOD_EDGE__NAME = eINSTANCE.getIOD_Edge_Name();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IOD_EDGE__SOURCE = eINSTANCE.getIOD_Edge_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IOD_EDGE__TARGET = eINSTANCE.getIOD_Edge_Target();

		/**
		 * The meta object literal for the '<em><b>Guard</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IOD_EDGE__GUARD = eINSTANCE.getIOD_Edge_Guard();

		/**
		 * The meta object literal for the '{@link org.eclipse.uml.iod.impl.IOD_NodeImpl <em>IOD Node</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.uml.iod.impl.IOD_NodeImpl
		 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getIOD_Node()
		 * @generated
		 */
		EClass IOD_NODE = eINSTANCE.getIOD_Node();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute IOD_NODE__NAME = eINSTANCE.getIOD_Node_Name();

		/**
		 * The meta object literal for the '{@link org.eclipse.uml.iod.impl.IOD_InteractionNodeImpl <em>IOD Interaction Node</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.uml.iod.impl.IOD_InteractionNodeImpl
		 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getIOD_InteractionNode()
		 * @generated
		 */
		EClass IOD_INTERACTION_NODE = eINSTANCE.getIOD_InteractionNode();

		/**
		 * The meta object literal for the '<em><b>Fragments</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IOD_INTERACTION_NODE__FRAGMENTS = eINSTANCE.getIOD_InteractionNode_Fragments();

		/**
		 * The meta object literal for the '<em><b>Lifeline</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IOD_INTERACTION_NODE__LIFELINE = eINSTANCE.getIOD_InteractionNode_Lifeline();

		/**
		 * The meta object literal for the '{@link org.eclipse.uml.iod.impl.EdgeConditionImpl <em>Edge Condition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.uml.iod.impl.EdgeConditionImpl
		 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getEdgeCondition()
		 * @generated
		 */
		EClass EDGE_CONDITION = eINSTANCE.getEdgeCondition();

		/**
		 * The meta object literal for the '<em><b>Clause</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EDGE_CONDITION__CLAUSE = eINSTANCE.getEdgeCondition_Clause();

		/**
		 * The meta object literal for the '{@link org.eclipse.uml.iod.impl.InteractionImpl <em>Interaction</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.uml.iod.impl.InteractionImpl
		 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getInteraction()
		 * @generated
		 */
		EClass INTERACTION = eINSTANCE.getInteraction();

		/**
		 * The meta object literal for the '{@link org.eclipse.uml.iod.impl.IOD_ControlNodeImpl <em>IOD Control Node</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.uml.iod.impl.IOD_ControlNodeImpl
		 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getIOD_ControlNode()
		 * @generated
		 */
		EClass IOD_CONTROL_NODE = eINSTANCE.getIOD_ControlNode();

		/**
		 * The meta object literal for the '{@link org.eclipse.uml.iod.impl.InitialNodeImpl <em>Initial Node</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.uml.iod.impl.InitialNodeImpl
		 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getInitialNode()
		 * @generated
		 */
		EClass INITIAL_NODE = eINSTANCE.getInitialNode();

		/**
		 * The meta object literal for the '{@link org.eclipse.uml.iod.impl.FinalNodeImpl <em>Final Node</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.uml.iod.impl.FinalNodeImpl
		 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getFinalNode()
		 * @generated
		 */
		EClass FINAL_NODE = eINSTANCE.getFinalNode();

		/**
		 * The meta object literal for the '{@link org.eclipse.uml.iod.impl.ForkNodeImpl <em>Fork Node</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.uml.iod.impl.ForkNodeImpl
		 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getForkNode()
		 * @generated
		 */
		EClass FORK_NODE = eINSTANCE.getForkNode();

		/**
		 * The meta object literal for the '{@link org.eclipse.uml.iod.impl.DecisionNodeImpl <em>Decision Node</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.uml.iod.impl.DecisionNodeImpl
		 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getDecisionNode()
		 * @generated
		 */
		EClass DECISION_NODE = eINSTANCE.getDecisionNode();

		/**
		 * The meta object literal for the '{@link org.eclipse.uml.iod.impl.JoinNodeImpl <em>Join Node</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.uml.iod.impl.JoinNodeImpl
		 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getJoinNode()
		 * @generated
		 */
		EClass JOIN_NODE = eINSTANCE.getJoinNode();

		/**
		 * The meta object literal for the '{@link org.eclipse.uml.iod.impl.MergeNodeImpl <em>Merge Node</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.uml.iod.impl.MergeNodeImpl
		 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getMergeNode()
		 * @generated
		 */
		EClass MERGE_NODE = eINSTANCE.getMergeNode();

		/**
		 * The meta object literal for the '{@link org.eclipse.uml.iod.impl.LifeLineImpl <em>Life Line</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.uml.iod.impl.LifeLineImpl
		 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getLifeLine()
		 * @generated
		 */
		EClass LIFE_LINE = eINSTANCE.getLifeLine();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LIFE_LINE__NAME = eINSTANCE.getLifeLine_Name();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LIFE_LINE__TYPE = eINSTANCE.getLifeLine_Type();

		/**
		 * The meta object literal for the '{@link org.eclipse.uml.iod.impl.CombinedFragmentImpl <em>Combined Fragment</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.uml.iod.impl.CombinedFragmentImpl
		 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getCombinedFragment()
		 * @generated
		 */
		EClass COMBINED_FRAGMENT = eINSTANCE.getCombinedFragment();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMBINED_FRAGMENT__NAME = eINSTANCE.getCombinedFragment_Name();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMBINED_FRAGMENT__TYPE = eINSTANCE.getCombinedFragment_Type();

		/**
		 * The meta object literal for the '<em><b>Operands</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COMBINED_FRAGMENT__OPERANDS = eINSTANCE.getCombinedFragment_Operands();

		/**
		 * The meta object literal for the '{@link org.eclipse.uml.iod.impl.MessageImpl <em>Message</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.uml.iod.impl.MessageImpl
		 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getMessage()
		 * @generated
		 */
		EClass MESSAGE = eINSTANCE.getMessage();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MESSAGE__NAME = eINSTANCE.getMessage_Name();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MESSAGE__TYPE = eINSTANCE.getMessage_Type();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MESSAGE__TARGET = eINSTANCE.getMessage_Target();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MESSAGE__SOURCE = eINSTANCE.getMessage_Source();

		/**
		 * The meta object literal for the '{@link org.eclipse.uml.iod.impl.OperandImpl <em>Operand</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.uml.iod.impl.OperandImpl
		 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getOperand()
		 * @generated
		 */
		EClass OPERAND = eINSTANCE.getOperand();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OPERAND__NAME = eINSTANCE.getOperand_Name();

		/**
		 * The meta object literal for the '<em><b>Operandfragments</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OPERAND__OPERANDFRAGMENTS = eINSTANCE.getOperand_Operandfragments();

		/**
		 * The meta object literal for the '<em><b>Loopparameters</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OPERAND__LOOPPARAMETERS = eINSTANCE.getOperand_Loopparameters();

		/**
		 * The meta object literal for the '<em><b>Guard</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OPERAND__GUARD = eINSTANCE.getOperand_Guard();

		/**
		 * The meta object literal for the '{@link org.eclipse.uml.iod.impl.oprdConditionImpl <em>oprd Condition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.uml.iod.impl.oprdConditionImpl
		 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getoprdCondition()
		 * @generated
		 */
		EClass OPRD_CONDITION = eINSTANCE.getoprdCondition();

		/**
		 * The meta object literal for the '<em><b>Clause</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OPRD_CONDITION__CLAUSE = eINSTANCE.getoprdCondition_Clause();

		/**
		 * The meta object literal for the '{@link org.eclipse.uml.iod.impl.LoopParametersImpl <em>Loop Parameters</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.uml.iod.impl.LoopParametersImpl
		 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getLoopParameters()
		 * @generated
		 */
		EClass LOOP_PARAMETERS = eINSTANCE.getLoopParameters();

		/**
		 * The meta object literal for the '<em><b>Loop Min</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOOP_PARAMETERS__LOOP_MIN = eINSTANCE.getLoopParameters_LoopMin();

		/**
		 * The meta object literal for the '<em><b>Loop Max</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOOP_PARAMETERS__LOOP_MAX = eINSTANCE.getLoopParameters_LoopMax();

		/**
		 * The meta object literal for the '{@link org.eclipse.uml.iod.OperatorTypes <em>Operator Types</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.uml.iod.OperatorTypes
		 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getOperatorTypes()
		 * @generated
		 */
		EEnum OPERATOR_TYPES = eINSTANCE.getOperatorTypes();

		/**
		 * The meta object literal for the '{@link org.eclipse.uml.iod.LLTypes <em>LL Types</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.uml.iod.LLTypes
		 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getLLTypes()
		 * @generated
		 */
		EEnum LL_TYPES = eINSTANCE.getLLTypes();

		/**
		 * The meta object literal for the '{@link org.eclipse.uml.iod.MessageTypes <em>Message Types</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.uml.iod.MessageTypes
		 * @see org.eclipse.uml.iod.impl.IodPackageImpl#getMessageTypes()
		 * @generated
		 */
		EEnum MESSAGE_TYPES = eINSTANCE.getMessageTypes();

	}

} //IodPackage
