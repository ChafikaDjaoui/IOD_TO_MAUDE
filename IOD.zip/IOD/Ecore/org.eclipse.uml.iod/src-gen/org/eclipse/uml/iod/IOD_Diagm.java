/**
 */
package org.eclipse.uml.iod;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>IOD Diagm</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.eclipse.uml.iod.IOD_Diagm#getName <em>Name</em>}</li>
 *   <li>{@link org.eclipse.uml.iod.IOD_Diagm#getNodes <em>Nodes</em>}</li>
 *   <li>{@link org.eclipse.uml.iod.IOD_Diagm#getEdges <em>Edges</em>}</li>
 * </ul>
 *
 * @see org.eclipse.uml.iod.IodPackage#getIOD_Diagm()
 * @model
 * @generated
 */
public interface IOD_Diagm extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.eclipse.uml.iod.IodPackage#getIOD_Diagm_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.eclipse.uml.iod.IOD_Diagm#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Nodes</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.uml.iod.IOD_Node}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nodes</em>' containment reference list.
	 * @see org.eclipse.uml.iod.IodPackage#getIOD_Diagm_Nodes()
	 * @model containment="true"
	 * @generated
	 */
	EList<IOD_Node> getNodes();

	/**
	 * Returns the value of the '<em><b>Edges</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.uml.iod.IOD_Edge}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Edges</em>' containment reference list.
	 * @see org.eclipse.uml.iod.IodPackage#getIOD_Diagm_Edges()
	 * @model containment="true"
	 * @generated
	 */
	EList<IOD_Edge> getEdges();

} // IOD_Diagm
