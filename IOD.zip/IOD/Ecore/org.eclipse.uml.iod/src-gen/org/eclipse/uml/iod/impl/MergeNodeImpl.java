/**
 */
package org.eclipse.uml.iod.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.uml.iod.IodPackage;
import org.eclipse.uml.iod.MergeNode;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Merge Node</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class MergeNodeImpl extends IOD_ControlNodeImpl implements MergeNode {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MergeNodeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return IodPackage.Literals.MERGE_NODE;
	}

} //MergeNodeImpl
