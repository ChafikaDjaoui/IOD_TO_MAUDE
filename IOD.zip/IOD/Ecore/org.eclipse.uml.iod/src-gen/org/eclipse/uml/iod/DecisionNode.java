/**
 */
package org.eclipse.uml.iod;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Decision Node</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.uml.iod.IodPackage#getDecisionNode()
 * @model
 * @generated
 */
public interface DecisionNode extends IOD_ControlNode {
} // DecisionNode
