/**
 */
package org.eclipse.uml.iod;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Loop Parameters</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.eclipse.uml.iod.LoopParameters#getLoopMin <em>Loop Min</em>}</li>
 *   <li>{@link org.eclipse.uml.iod.LoopParameters#getLoopMax <em>Loop Max</em>}</li>
 * </ul>
 *
 * @see org.eclipse.uml.iod.IodPackage#getLoopParameters()
 * @model
 * @generated
 */
public interface LoopParameters extends EObject {
	/**
	 * Returns the value of the '<em><b>Loop Min</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Loop Min</em>' attribute.
	 * @see #setLoopMin(String)
	 * @see org.eclipse.uml.iod.IodPackage#getLoopParameters_LoopMin()
	 * @model
	 * @generated
	 */
	String getLoopMin();

	/**
	 * Sets the value of the '{@link org.eclipse.uml.iod.LoopParameters#getLoopMin <em>Loop Min</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Loop Min</em>' attribute.
	 * @see #getLoopMin()
	 * @generated
	 */
	void setLoopMin(String value);

	/**
	 * Returns the value of the '<em><b>Loop Max</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Loop Max</em>' attribute.
	 * @see #setLoopMax(String)
	 * @see org.eclipse.uml.iod.IodPackage#getLoopParameters_LoopMax()
	 * @model
	 * @generated
	 */
	String getLoopMax();

	/**
	 * Sets the value of the '{@link org.eclipse.uml.iod.LoopParameters#getLoopMax <em>Loop Max</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Loop Max</em>' attribute.
	 * @see #getLoopMax()
	 * @generated
	 */
	void setLoopMax(String value);

} // LoopParameters
