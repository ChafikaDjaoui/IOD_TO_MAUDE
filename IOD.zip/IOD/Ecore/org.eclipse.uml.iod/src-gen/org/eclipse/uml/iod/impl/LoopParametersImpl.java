/**
 */
package org.eclipse.uml.iod.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.uml.iod.IodPackage;
import org.eclipse.uml.iod.LoopParameters;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Loop Parameters</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.eclipse.uml.iod.impl.LoopParametersImpl#getLoopMin <em>Loop Min</em>}</li>
 *   <li>{@link org.eclipse.uml.iod.impl.LoopParametersImpl#getLoopMax <em>Loop Max</em>}</li>
 * </ul>
 *
 * @generated
 */
public class LoopParametersImpl extends MinimalEObjectImpl.Container implements LoopParameters {
	/**
	 * The default value of the '{@link #getLoopMin() <em>Loop Min</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLoopMin()
	 * @generated
	 * @ordered
	 */
	protected static final String LOOP_MIN_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLoopMin() <em>Loop Min</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLoopMin()
	 * @generated
	 * @ordered
	 */
	protected String loopMin = LOOP_MIN_EDEFAULT;

	/**
	 * The default value of the '{@link #getLoopMax() <em>Loop Max</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLoopMax()
	 * @generated
	 * @ordered
	 */
	protected static final String LOOP_MAX_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLoopMax() <em>Loop Max</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLoopMax()
	 * @generated
	 * @ordered
	 */
	protected String loopMax = LOOP_MAX_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LoopParametersImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return IodPackage.Literals.LOOP_PARAMETERS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLoopMin() {
		return loopMin;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLoopMin(String newLoopMin) {
		String oldLoopMin = loopMin;
		loopMin = newLoopMin;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IodPackage.LOOP_PARAMETERS__LOOP_MIN, oldLoopMin,
					loopMin));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLoopMax() {
		return loopMax;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLoopMax(String newLoopMax) {
		String oldLoopMax = loopMax;
		loopMax = newLoopMax;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IodPackage.LOOP_PARAMETERS__LOOP_MAX, oldLoopMax,
					loopMax));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case IodPackage.LOOP_PARAMETERS__LOOP_MIN:
			return getLoopMin();
		case IodPackage.LOOP_PARAMETERS__LOOP_MAX:
			return getLoopMax();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case IodPackage.LOOP_PARAMETERS__LOOP_MIN:
			setLoopMin((String) newValue);
			return;
		case IodPackage.LOOP_PARAMETERS__LOOP_MAX:
			setLoopMax((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case IodPackage.LOOP_PARAMETERS__LOOP_MIN:
			setLoopMin(LOOP_MIN_EDEFAULT);
			return;
		case IodPackage.LOOP_PARAMETERS__LOOP_MAX:
			setLoopMax(LOOP_MAX_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case IodPackage.LOOP_PARAMETERS__LOOP_MIN:
			return LOOP_MIN_EDEFAULT == null ? loopMin != null : !LOOP_MIN_EDEFAULT.equals(loopMin);
		case IodPackage.LOOP_PARAMETERS__LOOP_MAX:
			return LOOP_MAX_EDEFAULT == null ? loopMax != null : !LOOP_MAX_EDEFAULT.equals(loopMax);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (LoopMin: ");
		result.append(loopMin);
		result.append(", LoopMax: ");
		result.append(loopMax);
		result.append(')');
		return result.toString();
	}

} //LoopParametersImpl
