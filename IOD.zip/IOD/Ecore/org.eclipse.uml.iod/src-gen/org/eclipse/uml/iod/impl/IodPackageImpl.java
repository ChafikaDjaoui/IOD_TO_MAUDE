/**
 */
package org.eclipse.uml.iod.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.eclipse.uml.iod.CombinedFragment;
import org.eclipse.uml.iod.DecisionNode;
import org.eclipse.uml.iod.EdgeCondition;
import org.eclipse.uml.iod.FinalNode;
import org.eclipse.uml.iod.ForkNode;
import org.eclipse.uml.iod.IOD_ControlNode;
import org.eclipse.uml.iod.IOD_Diagm;
import org.eclipse.uml.iod.IOD_Edge;
import org.eclipse.uml.iod.IOD_InteractionNode;
import org.eclipse.uml.iod.IOD_Node;
import org.eclipse.uml.iod.InitialNode;
import org.eclipse.uml.iod.Interaction;
import org.eclipse.uml.iod.IodFactory;
import org.eclipse.uml.iod.IodPackage;
import org.eclipse.uml.iod.JoinNode;
import org.eclipse.uml.iod.LLTypes;
import org.eclipse.uml.iod.LifeLine;
import org.eclipse.uml.iod.LoopParameters;
import org.eclipse.uml.iod.MergeNode;
import org.eclipse.uml.iod.Message;
import org.eclipse.uml.iod.MessageTypes;
import org.eclipse.uml.iod.Operand;
import org.eclipse.uml.iod.OperatorTypes;
import org.eclipse.uml.iod.oprdCondition;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class IodPackageImpl extends EPackageImpl implements IodPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass ioD_DiagmEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass ioD_EdgeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass ioD_NodeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass ioD_InteractionNodeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass edgeConditionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass interactionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass ioD_ControlNodeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass initialNodeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass finalNodeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass forkNodeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass decisionNodeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass joinNodeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mergeNodeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass lifeLineEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass combinedFragmentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass messageEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass operandEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass oprdConditionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass loopParametersEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum operatorTypesEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum llTypesEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum messageTypesEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see org.eclipse.uml.iod.IodPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private IodPackageImpl() {
		super(eNS_URI, IodFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link IodPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static IodPackage init() {
		if (isInited)
			return (IodPackage) EPackage.Registry.INSTANCE.getEPackage(IodPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredIodPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		IodPackageImpl theIodPackage = registeredIodPackage instanceof IodPackageImpl
				? (IodPackageImpl) registeredIodPackage
				: new IodPackageImpl();

		isInited = true;

		// Create package meta-data objects
		theIodPackage.createPackageContents();

		// Initialize created meta-data
		theIodPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theIodPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(IodPackage.eNS_URI, theIodPackage);
		return theIodPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getIOD_Diagm() {
		return ioD_DiagmEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getIOD_Diagm_Name() {
		return (EAttribute) ioD_DiagmEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIOD_Diagm_Nodes() {
		return (EReference) ioD_DiagmEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIOD_Diagm_Edges() {
		return (EReference) ioD_DiagmEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getIOD_Edge() {
		return ioD_EdgeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getIOD_Edge_Name() {
		return (EAttribute) ioD_EdgeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIOD_Edge_Source() {
		return (EReference) ioD_EdgeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIOD_Edge_Target() {
		return (EReference) ioD_EdgeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIOD_Edge_Guard() {
		return (EReference) ioD_EdgeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getIOD_Node() {
		return ioD_NodeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getIOD_Node_Name() {
		return (EAttribute) ioD_NodeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getIOD_InteractionNode() {
		return ioD_InteractionNodeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIOD_InteractionNode_Fragments() {
		return (EReference) ioD_InteractionNodeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIOD_InteractionNode_Lifeline() {
		return (EReference) ioD_InteractionNodeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEdgeCondition() {
		return edgeConditionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEdgeCondition_Clause() {
		return (EAttribute) edgeConditionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getInteraction() {
		return interactionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getIOD_ControlNode() {
		return ioD_ControlNodeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getInitialNode() {
		return initialNodeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFinalNode() {
		return finalNodeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getForkNode() {
		return forkNodeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDecisionNode() {
		return decisionNodeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getJoinNode() {
		return joinNodeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMergeNode() {
		return mergeNodeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getLifeLine() {
		return lifeLineEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLifeLine_Name() {
		return (EAttribute) lifeLineEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLifeLine_Type() {
		return (EAttribute) lifeLineEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCombinedFragment() {
		return combinedFragmentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCombinedFragment_Name() {
		return (EAttribute) combinedFragmentEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCombinedFragment_Type() {
		return (EAttribute) combinedFragmentEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCombinedFragment_Operands() {
		return (EReference) combinedFragmentEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMessage() {
		return messageEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMessage_Name() {
		return (EAttribute) messageEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMessage_Type() {
		return (EAttribute) messageEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMessage_Target() {
		return (EReference) messageEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMessage_Source() {
		return (EReference) messageEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOperand() {
		return operandEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOperand_Name() {
		return (EAttribute) operandEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOperand_Operandfragments() {
		return (EReference) operandEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOperand_Loopparameters() {
		return (EReference) operandEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOperand_Guard() {
		return (EReference) operandEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getoprdCondition() {
		return oprdConditionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getoprdCondition_Clause() {
		return (EAttribute) oprdConditionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getLoopParameters() {
		return loopParametersEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLoopParameters_LoopMin() {
		return (EAttribute) loopParametersEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLoopParameters_LoopMax() {
		return (EAttribute) loopParametersEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getOperatorTypes() {
		return operatorTypesEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getLLTypes() {
		return llTypesEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getMessageTypes() {
		return messageTypesEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IodFactory getIodFactory() {
		return (IodFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		ioD_DiagmEClass = createEClass(IOD_DIAGM);
		createEAttribute(ioD_DiagmEClass, IOD_DIAGM__NAME);
		createEReference(ioD_DiagmEClass, IOD_DIAGM__NODES);
		createEReference(ioD_DiagmEClass, IOD_DIAGM__EDGES);

		ioD_EdgeEClass = createEClass(IOD_EDGE);
		createEAttribute(ioD_EdgeEClass, IOD_EDGE__NAME);
		createEReference(ioD_EdgeEClass, IOD_EDGE__SOURCE);
		createEReference(ioD_EdgeEClass, IOD_EDGE__TARGET);
		createEReference(ioD_EdgeEClass, IOD_EDGE__GUARD);

		ioD_NodeEClass = createEClass(IOD_NODE);
		createEAttribute(ioD_NodeEClass, IOD_NODE__NAME);

		ioD_InteractionNodeEClass = createEClass(IOD_INTERACTION_NODE);
		createEReference(ioD_InteractionNodeEClass, IOD_INTERACTION_NODE__FRAGMENTS);
		createEReference(ioD_InteractionNodeEClass, IOD_INTERACTION_NODE__LIFELINE);

		edgeConditionEClass = createEClass(EDGE_CONDITION);
		createEAttribute(edgeConditionEClass, EDGE_CONDITION__CLAUSE);

		interactionEClass = createEClass(INTERACTION);

		ioD_ControlNodeEClass = createEClass(IOD_CONTROL_NODE);

		initialNodeEClass = createEClass(INITIAL_NODE);

		finalNodeEClass = createEClass(FINAL_NODE);

		forkNodeEClass = createEClass(FORK_NODE);

		decisionNodeEClass = createEClass(DECISION_NODE);

		joinNodeEClass = createEClass(JOIN_NODE);

		mergeNodeEClass = createEClass(MERGE_NODE);

		lifeLineEClass = createEClass(LIFE_LINE);
		createEAttribute(lifeLineEClass, LIFE_LINE__NAME);
		createEAttribute(lifeLineEClass, LIFE_LINE__TYPE);

		combinedFragmentEClass = createEClass(COMBINED_FRAGMENT);
		createEAttribute(combinedFragmentEClass, COMBINED_FRAGMENT__NAME);
		createEAttribute(combinedFragmentEClass, COMBINED_FRAGMENT__TYPE);
		createEReference(combinedFragmentEClass, COMBINED_FRAGMENT__OPERANDS);

		messageEClass = createEClass(MESSAGE);
		createEAttribute(messageEClass, MESSAGE__NAME);
		createEAttribute(messageEClass, MESSAGE__TYPE);
		createEReference(messageEClass, MESSAGE__TARGET);
		createEReference(messageEClass, MESSAGE__SOURCE);

		operandEClass = createEClass(OPERAND);
		createEAttribute(operandEClass, OPERAND__NAME);
		createEReference(operandEClass, OPERAND__OPERANDFRAGMENTS);
		createEReference(operandEClass, OPERAND__LOOPPARAMETERS);
		createEReference(operandEClass, OPERAND__GUARD);

		oprdConditionEClass = createEClass(OPRD_CONDITION);
		createEAttribute(oprdConditionEClass, OPRD_CONDITION__CLAUSE);

		loopParametersEClass = createEClass(LOOP_PARAMETERS);
		createEAttribute(loopParametersEClass, LOOP_PARAMETERS__LOOP_MIN);
		createEAttribute(loopParametersEClass, LOOP_PARAMETERS__LOOP_MAX);

		// Create enums
		operatorTypesEEnum = createEEnum(OPERATOR_TYPES);
		llTypesEEnum = createEEnum(LL_TYPES);
		messageTypesEEnum = createEEnum(MESSAGE_TYPES);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		ioD_InteractionNodeEClass.getESuperTypes().add(this.getIOD_Node());
		ioD_ControlNodeEClass.getESuperTypes().add(this.getIOD_Node());
		initialNodeEClass.getESuperTypes().add(this.getIOD_ControlNode());
		finalNodeEClass.getESuperTypes().add(this.getIOD_ControlNode());
		forkNodeEClass.getESuperTypes().add(this.getIOD_ControlNode());
		decisionNodeEClass.getESuperTypes().add(this.getIOD_ControlNode());
		joinNodeEClass.getESuperTypes().add(this.getIOD_ControlNode());
		mergeNodeEClass.getESuperTypes().add(this.getIOD_ControlNode());
		combinedFragmentEClass.getESuperTypes().add(this.getInteraction());
		messageEClass.getESuperTypes().add(this.getInteraction());

		// Initialize classes, features, and operations; add parameters
		initEClass(ioD_DiagmEClass, IOD_Diagm.class, "IOD_Diagm", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getIOD_Diagm_Name(), ecorePackage.getEString(), "Name", null, 0, 1, IOD_Diagm.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getIOD_Diagm_Nodes(), this.getIOD_Node(), null, "nodes", null, 0, -1, IOD_Diagm.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getIOD_Diagm_Edges(), this.getIOD_Edge(), null, "edges", null, 0, -1, IOD_Diagm.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(ioD_EdgeEClass, IOD_Edge.class, "IOD_Edge", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getIOD_Edge_Name(), ecorePackage.getEString(), "Name", null, 0, 1, IOD_Edge.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getIOD_Edge_Source(), this.getIOD_Node(), null, "source", null, 0, 1, IOD_Edge.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getIOD_Edge_Target(), this.getIOD_Node(), null, "target", null, 0, 1, IOD_Edge.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getIOD_Edge_Guard(), this.getEdgeCondition(), null, "guard", null, 0, 1, IOD_Edge.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(ioD_NodeEClass, IOD_Node.class, "IOD_Node", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getIOD_Node_Name(), ecorePackage.getEString(), "Name", null, 0, 1, IOD_Node.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(ioD_InteractionNodeEClass, IOD_InteractionNode.class, "IOD_InteractionNode", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getIOD_InteractionNode_Fragments(), this.getInteraction(), null, "fragments", null, 1, -1,
				IOD_InteractionNode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getIOD_InteractionNode_Lifeline(), this.getLifeLine(), null, "lifeline", null, 2, -1,
				IOD_InteractionNode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(edgeConditionEClass, EdgeCondition.class, "EdgeCondition", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getEdgeCondition_Clause(), ecorePackage.getEString(), "Clause", null, 0, 1, EdgeCondition.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(interactionEClass, Interaction.class, "Interaction", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(ioD_ControlNodeEClass, IOD_ControlNode.class, "IOD_ControlNode", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(initialNodeEClass, InitialNode.class, "InitialNode", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(finalNodeEClass, FinalNode.class, "FinalNode", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(forkNodeEClass, ForkNode.class, "ForkNode", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(decisionNodeEClass, DecisionNode.class, "DecisionNode", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(joinNodeEClass, JoinNode.class, "JoinNode", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(mergeNodeEClass, MergeNode.class, "MergeNode", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(lifeLineEClass, LifeLine.class, "LifeLine", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getLifeLine_Name(), ecorePackage.getEString(), "Name", null, 0, 1, LifeLine.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getLifeLine_Type(), this.getLLTypes(), "Type", null, 0, 1, LifeLine.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(combinedFragmentEClass, CombinedFragment.class, "CombinedFragment", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCombinedFragment_Name(), ecorePackage.getEString(), "Name", null, 0, 1,
				CombinedFragment.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getCombinedFragment_Type(), this.getOperatorTypes(), "Type", null, 0, 1, CombinedFragment.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCombinedFragment_Operands(), this.getOperand(), null, "operands", null, 0, -1,
				CombinedFragment.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(messageEClass, Message.class, "Message", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMessage_Name(), ecorePackage.getEString(), "Name", null, 0, 1, Message.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMessage_Type(), this.getMessageTypes(), "Type", null, 0, 1, Message.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMessage_Target(), this.getLifeLine(), null, "target", null, 1, 1, Message.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMessage_Source(), this.getLifeLine(), null, "source", null, 1, 1, Message.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(operandEClass, Operand.class, "Operand", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getOperand_Name(), ecorePackage.getEString(), "Name", null, 0, 1, Operand.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getOperand_Operandfragments(), this.getInteraction(), null, "operandfragments", null, 0, -1,
				Operand.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getOperand_Loopparameters(), this.getLoopParameters(), null, "loopparameters", null, 0, -1,
				Operand.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getOperand_Guard(), this.getoprdCondition(), null, "guard", null, 0, 1, Operand.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(oprdConditionEClass, oprdCondition.class, "oprdCondition", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getoprdCondition_Clause(), ecorePackage.getEString(), "Clause", null, 0, 1, oprdCondition.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(loopParametersEClass, LoopParameters.class, "LoopParameters", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getLoopParameters_LoopMin(), ecorePackage.getEString(), "LoopMin", null, 0, 1,
				LoopParameters.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getLoopParameters_LoopMax(), ecorePackage.getEString(), "LoopMax", null, 0, 1,
				LoopParameters.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(operatorTypesEEnum, OperatorTypes.class, "OperatorTypes");
		addEEnumLiteral(operatorTypesEEnum, OperatorTypes.OPT);
		addEEnumLiteral(operatorTypesEEnum, OperatorTypes.ALT);
		addEEnumLiteral(operatorTypesEEnum, OperatorTypes.LOOP);
		addEEnumLiteral(operatorTypesEEnum, OperatorTypes.PAR);
		addEEnumLiteral(operatorTypesEEnum, OperatorTypes.BREAK);
		addEEnumLiteral(operatorTypesEEnum, OperatorTypes.STRICT);
		addEEnumLiteral(operatorTypesEEnum, OperatorTypes.SEQ);

		initEEnum(llTypesEEnum, LLTypes.class, "LLTypes");
		addEEnumLiteral(llTypesEEnum, LLTypes.OBJECT);
		addEEnumLiteral(llTypesEEnum, LLTypes.ACTOR);

		initEEnum(messageTypesEEnum, MessageTypes.class, "MessageTypes");
		addEEnumLiteral(messageTypesEEnum, MessageTypes.SYNCH_CALL);
		addEEnumLiteral(messageTypesEEnum, MessageTypes.ASYNCH_CALL);
		addEEnumLiteral(messageTypesEEnum, MessageTypes.REPLY);

		// Create resource
		createResource(eNS_URI);
	}

} //IodPackageImpl
