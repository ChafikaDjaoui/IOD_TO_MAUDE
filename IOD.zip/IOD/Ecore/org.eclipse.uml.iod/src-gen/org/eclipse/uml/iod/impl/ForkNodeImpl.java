/**
 */
package org.eclipse.uml.iod.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.uml.iod.ForkNode;
import org.eclipse.uml.iod.IodPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Fork Node</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ForkNodeImpl extends IOD_ControlNodeImpl implements ForkNode {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ForkNodeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return IodPackage.Literals.FORK_NODE;
	}

} //ForkNodeImpl
