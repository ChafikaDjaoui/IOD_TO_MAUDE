/**
 */
package org.eclipse.uml.iod;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Join Node</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.uml.iod.IodPackage#getJoinNode()
 * @model
 * @generated
 */
public interface JoinNode extends IOD_ControlNode {
} // JoinNode
