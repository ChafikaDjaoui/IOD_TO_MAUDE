/**
 */
package org.eclipse.uml.iod;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Operand</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.eclipse.uml.iod.Operand#getName <em>Name</em>}</li>
 *   <li>{@link org.eclipse.uml.iod.Operand#getOperandfragments <em>Operandfragments</em>}</li>
 *   <li>{@link org.eclipse.uml.iod.Operand#getLoopparameters <em>Loopparameters</em>}</li>
 *   <li>{@link org.eclipse.uml.iod.Operand#getGuard <em>Guard</em>}</li>
 * </ul>
 *
 * @see org.eclipse.uml.iod.IodPackage#getOperand()
 * @model
 * @generated
 */
public interface Operand extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.eclipse.uml.iod.IodPackage#getOperand_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.eclipse.uml.iod.Operand#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Operandfragments</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.uml.iod.Interaction}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operandfragments</em>' containment reference list.
	 * @see org.eclipse.uml.iod.IodPackage#getOperand_Operandfragments()
	 * @model containment="true"
	 * @generated
	 */
	EList<Interaction> getOperandfragments();

	/**
	 * Returns the value of the '<em><b>Loopparameters</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.uml.iod.LoopParameters}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Loopparameters</em>' containment reference list.
	 * @see org.eclipse.uml.iod.IodPackage#getOperand_Loopparameters()
	 * @model containment="true"
	 * @generated
	 */
	EList<LoopParameters> getLoopparameters();

	/**
	 * Returns the value of the '<em><b>Guard</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Guard</em>' containment reference.
	 * @see #setGuard(oprdCondition)
	 * @see org.eclipse.uml.iod.IodPackage#getOperand_Guard()
	 * @model containment="true"
	 * @generated
	 */
	oprdCondition getGuard();

	/**
	 * Sets the value of the '{@link org.eclipse.uml.iod.Operand#getGuard <em>Guard</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Guard</em>' containment reference.
	 * @see #getGuard()
	 * @generated
	 */
	void setGuard(oprdCondition value);

} // Operand
