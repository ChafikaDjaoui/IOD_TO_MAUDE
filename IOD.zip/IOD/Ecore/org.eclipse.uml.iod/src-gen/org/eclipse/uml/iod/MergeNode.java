/**
 */
package org.eclipse.uml.iod;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Merge Node</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.uml.iod.IodPackage#getMergeNode()
 * @model
 * @generated
 */
public interface MergeNode extends IOD_ControlNode {
} // MergeNode
