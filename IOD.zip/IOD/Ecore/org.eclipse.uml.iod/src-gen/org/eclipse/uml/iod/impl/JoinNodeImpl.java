/**
 */
package org.eclipse.uml.iod.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.uml.iod.IodPackage;
import org.eclipse.uml.iod.JoinNode;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Join Node</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class JoinNodeImpl extends IOD_ControlNodeImpl implements JoinNode {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected JoinNodeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return IodPackage.Literals.JOIN_NODE;
	}

} //JoinNodeImpl
