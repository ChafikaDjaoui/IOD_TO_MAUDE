/**
 */
package org.eclipse.uml.iod;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>IOD Edge</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.eclipse.uml.iod.IOD_Edge#getName <em>Name</em>}</li>
 *   <li>{@link org.eclipse.uml.iod.IOD_Edge#getSource <em>Source</em>}</li>
 *   <li>{@link org.eclipse.uml.iod.IOD_Edge#getTarget <em>Target</em>}</li>
 *   <li>{@link org.eclipse.uml.iod.IOD_Edge#getGuard <em>Guard</em>}</li>
 * </ul>
 *
 * @see org.eclipse.uml.iod.IodPackage#getIOD_Edge()
 * @model
 * @generated
 */
public interface IOD_Edge extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.eclipse.uml.iod.IodPackage#getIOD_Edge_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.eclipse.uml.iod.IOD_Edge#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' reference.
	 * @see #setSource(IOD_Node)
	 * @see org.eclipse.uml.iod.IodPackage#getIOD_Edge_Source()
	 * @model
	 * @generated
	 */
	IOD_Node getSource();

	/**
	 * Sets the value of the '{@link org.eclipse.uml.iod.IOD_Edge#getSource <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' reference.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(IOD_Node value);

	/**
	 * Returns the value of the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' reference.
	 * @see #setTarget(IOD_Node)
	 * @see org.eclipse.uml.iod.IodPackage#getIOD_Edge_Target()
	 * @model
	 * @generated
	 */
	IOD_Node getTarget();

	/**
	 * Sets the value of the '{@link org.eclipse.uml.iod.IOD_Edge#getTarget <em>Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target</em>' reference.
	 * @see #getTarget()
	 * @generated
	 */
	void setTarget(IOD_Node value);

	/**
	 * Returns the value of the '<em><b>Guard</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Guard</em>' containment reference.
	 * @see #setGuard(EdgeCondition)
	 * @see org.eclipse.uml.iod.IodPackage#getIOD_Edge_Guard()
	 * @model containment="true"
	 * @generated
	 */
	EdgeCondition getGuard();

	/**
	 * Sets the value of the '{@link org.eclipse.uml.iod.IOD_Edge#getGuard <em>Guard</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Guard</em>' containment reference.
	 * @see #getGuard()
	 * @generated
	 */
	void setGuard(EdgeCondition value);

} // IOD_Edge
