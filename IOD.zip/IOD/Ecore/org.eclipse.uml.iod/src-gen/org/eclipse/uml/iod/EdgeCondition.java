/**
 */
package org.eclipse.uml.iod;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Edge Condition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.eclipse.uml.iod.EdgeCondition#getClause <em>Clause</em>}</li>
 * </ul>
 *
 * @see org.eclipse.uml.iod.IodPackage#getEdgeCondition()
 * @model
 * @generated
 */
public interface EdgeCondition extends EObject {
	/**
	 * Returns the value of the '<em><b>Clause</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Clause</em>' attribute.
	 * @see #setClause(String)
	 * @see org.eclipse.uml.iod.IodPackage#getEdgeCondition_Clause()
	 * @model
	 * @generated
	 */
	String getClause();

	/**
	 * Sets the value of the '{@link org.eclipse.uml.iod.EdgeCondition#getClause <em>Clause</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Clause</em>' attribute.
	 * @see #getClause()
	 * @generated
	 */
	void setClause(String value);

} // EdgeCondition
