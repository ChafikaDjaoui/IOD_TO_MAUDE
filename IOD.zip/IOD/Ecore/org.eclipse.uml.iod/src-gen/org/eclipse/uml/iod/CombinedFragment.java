/**
 */
package org.eclipse.uml.iod;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Combined Fragment</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.eclipse.uml.iod.CombinedFragment#getName <em>Name</em>}</li>
 *   <li>{@link org.eclipse.uml.iod.CombinedFragment#getType <em>Type</em>}</li>
 *   <li>{@link org.eclipse.uml.iod.CombinedFragment#getOperands <em>Operands</em>}</li>
 * </ul>
 *
 * @see org.eclipse.uml.iod.IodPackage#getCombinedFragment()
 * @model
 * @generated
 */
public interface CombinedFragment extends Interaction {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.eclipse.uml.iod.IodPackage#getCombinedFragment_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.eclipse.uml.iod.CombinedFragment#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link org.eclipse.uml.iod.OperatorTypes}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see org.eclipse.uml.iod.OperatorTypes
	 * @see #setType(OperatorTypes)
	 * @see org.eclipse.uml.iod.IodPackage#getCombinedFragment_Type()
	 * @model
	 * @generated
	 */
	OperatorTypes getType();

	/**
	 * Sets the value of the '{@link org.eclipse.uml.iod.CombinedFragment#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see org.eclipse.uml.iod.OperatorTypes
	 * @see #getType()
	 * @generated
	 */
	void setType(OperatorTypes value);

	/**
	 * Returns the value of the '<em><b>Operands</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.uml.iod.Operand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operands</em>' containment reference list.
	 * @see org.eclipse.uml.iod.IodPackage#getCombinedFragment_Operands()
	 * @model containment="true"
	 * @generated
	 */
	EList<Operand> getOperands();

} // CombinedFragment
