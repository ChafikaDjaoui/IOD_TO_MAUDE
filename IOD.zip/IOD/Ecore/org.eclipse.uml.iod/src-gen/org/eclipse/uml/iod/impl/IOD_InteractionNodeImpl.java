/**
 */
package org.eclipse.uml.iod.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eclipse.uml.iod.IOD_InteractionNode;
import org.eclipse.uml.iod.Interaction;
import org.eclipse.uml.iod.IodPackage;
import org.eclipse.uml.iod.LifeLine;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>IOD Interaction Node</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.eclipse.uml.iod.impl.IOD_InteractionNodeImpl#getFragments <em>Fragments</em>}</li>
 *   <li>{@link org.eclipse.uml.iod.impl.IOD_InteractionNodeImpl#getLifeline <em>Lifeline</em>}</li>
 * </ul>
 *
 * @generated
 */
public class IOD_InteractionNodeImpl extends IOD_NodeImpl implements IOD_InteractionNode {
	/**
	 * The cached value of the '{@link #getFragments() <em>Fragments</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFragments()
	 * @generated
	 * @ordered
	 */
	protected EList<Interaction> fragments;

	/**
	 * The cached value of the '{@link #getLifeline() <em>Lifeline</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLifeline()
	 * @generated
	 * @ordered
	 */
	protected EList<LifeLine> lifeline;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IOD_InteractionNodeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return IodPackage.Literals.IOD_INTERACTION_NODE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Interaction> getFragments() {
		if (fragments == null) {
			fragments = new EObjectContainmentEList<Interaction>(Interaction.class, this,
					IodPackage.IOD_INTERACTION_NODE__FRAGMENTS);
		}
		return fragments;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<LifeLine> getLifeline() {
		if (lifeline == null) {
			lifeline = new EObjectContainmentEList<LifeLine>(LifeLine.class, this,
					IodPackage.IOD_INTERACTION_NODE__LIFELINE);
		}
		return lifeline;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case IodPackage.IOD_INTERACTION_NODE__FRAGMENTS:
			return ((InternalEList<?>) getFragments()).basicRemove(otherEnd, msgs);
		case IodPackage.IOD_INTERACTION_NODE__LIFELINE:
			return ((InternalEList<?>) getLifeline()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case IodPackage.IOD_INTERACTION_NODE__FRAGMENTS:
			return getFragments();
		case IodPackage.IOD_INTERACTION_NODE__LIFELINE:
			return getLifeline();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case IodPackage.IOD_INTERACTION_NODE__FRAGMENTS:
			getFragments().clear();
			getFragments().addAll((Collection<? extends Interaction>) newValue);
			return;
		case IodPackage.IOD_INTERACTION_NODE__LIFELINE:
			getLifeline().clear();
			getLifeline().addAll((Collection<? extends LifeLine>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case IodPackage.IOD_INTERACTION_NODE__FRAGMENTS:
			getFragments().clear();
			return;
		case IodPackage.IOD_INTERACTION_NODE__LIFELINE:
			getLifeline().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case IodPackage.IOD_INTERACTION_NODE__FRAGMENTS:
			return fragments != null && !fragments.isEmpty();
		case IodPackage.IOD_INTERACTION_NODE__LIFELINE:
			return lifeline != null && !lifeline.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //IOD_InteractionNodeImpl
